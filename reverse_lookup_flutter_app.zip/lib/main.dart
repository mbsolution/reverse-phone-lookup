import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(ReverseLookupApp());

class ReverseLookupApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reverse Phone Lookup',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LookupPage(),
    );
  }
}

class LookupPage extends StatefulWidget {
  @override
  _LookupPageState createState() => _LookupPageState();
}

class _LookupPageState extends State<LookupPage> {
  final TextEditingController _controller = TextEditingController();
  Map<String, dynamic>? _lookupResult;
  bool _loading = false;

  Future<void> _searchPhoneNumber() async {
    setState(() => _loading = true);
    final response = await http.get(Uri.parse(
        'https://raw.githubusercontent.com/mbsolution/reverse-phone-lookup/main/mock_reverse_lookup.json'));
    if (response.statusCode == 200) {
      setState(() {
        _lookupResult = json.decode(response.body);
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load data.')),
      );
    }
  }

  Widget _buildProfileCard(Map profile) {
    return ListTile(
      leading: CircleAvatar(backgroundImage: NetworkImage(profile['profile_image'])),
      title: Text(profile['platform']),
      subtitle: Text(profile['username']),
      onTap: () => launchUrl(Uri.parse(profile['profile_url'])),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Reverse Lookup')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter Phone Number',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _loading ? null : _searchPhoneNumber,
              child: _loading ? CircularProgressIndicator() : Text('Search'),
            ),
            SizedBox(height: 20),
            _lookupResult != null
                ? Expanded(
                    child: ListView(
                      children: [
                        Text('Name: ${_lookupResult!['caller_name']}'),
                        Text('Carrier: ${_lookupResult!['carrier']}'),
                        Text('Location: ${_lookupResult!['location']}'),
                        Text('Spam Score: ${_lookupResult!['spam_score']}'),
                        Divider(),
                        Text('Social Profiles:', style: TextStyle(fontWeight: FontWeight.bold)),
                        ...(_lookupResult!['social_profiles'] as List)
                            .map((profile) => _buildProfileCard(profile))
                      ],
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }
}
